-- Run this in Java DB (Derby) ij or your SQL tool
CREATE TABLE PATIENTS (
    ID INT PRIMARY KEY,
    NAME VARCHAR(50),
    AGE INT,
    DIAGNOSIS VARCHAR(100)
);

INSERT INTO PATIENTS (ID, NAME, AGE, DIAGNOSIS) VALUES
(1,'Helen James',45,'Flu'),
(2,'Eric Khan',30,'Broken Arm'),
(3,'Tommy Lee',55,'Diabetes'),
(4,'Priyanka Collins',29,'Allergy');
