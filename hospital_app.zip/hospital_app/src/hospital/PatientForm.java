package hospital;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.Vector;

// JasperReports imports
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class PatientForm extends JFrame {
    private JTextField txtId = new JTextField();
    private JTextField txtName = new JTextField();
    private JTextField txtAge = new JTextField();
    private JTextField txtDiagnosis = new JTextField();

    private JButton btnNew = new JButton("Tambah");
    private JButton btnSave = new JButton("Edit"); // label diubah menjadi Edit
    private JButton btnDelete = new JButton("Hapus");
    private JButton btnReport = new JButton("Cetak Data"); // label diubah menjadi Cetak Data

    private JTable table;
    private DefaultTableModel tableModel;

    private PatientDAO dao;

    public PatientForm() {
        super("Data Pasien");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(700, 500);
        setLocationRelativeTo(null);

        // Panel utama
        JPanel panelUtama = new JPanel(new BorderLayout(10, 10));
        panelUtama.setBackground(new Color(173, 216, 230));
        panelUtama.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setContentPane(panelUtama);

        JLabel title = new JLabel("DATA PASIEN", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        panelUtama.add(title, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setOpaque(false);
        formPanel.add(new JLabel("ID"));
        formPanel.add(txtId);
        formPanel.add(new JLabel("Nama"));
        formPanel.add(txtName);
        formPanel.add(new JLabel("Usia"));
        formPanel.add(txtAge);
        formPanel.add(new JLabel("Diagnosis"));
        formPanel.add(txtDiagnosis);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        buttonPanel.setOpaque(false);
        buttonPanel.add(btnNew);
        buttonPanel.add(btnSave);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnReport);

        JPanel atas = new JPanel(new BorderLayout());
        atas.setOpaque(false);
        atas.add(formPanel, BorderLayout.CENTER);
        atas.add(buttonPanel, BorderLayout.SOUTH);
        panelUtama.add(atas, BorderLayout.CENTER);

        // Tabel
        tableModel = new DefaultTableModel(new Object[]{"ID", "Nama", "Usia", "Diagnosis"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(680, 200));
        panelUtama.add(scrollPane, BorderLayout.SOUTH);

        try {
            dao = new PatientDAO();
            loadTable();
        } catch (SQLException ex) {
            showError(ex);
        }

        // Tombol aksi
        btnNew.addActionListener(e -> tambahPasien());
        btnSave.addActionListener(e -> saveNew());
        btnDelete.addActionListener(e -> deleteSelected());
        btnReport.addActionListener(e -> HospitalReport.showReport(this));

        // Isi form saat baris tabel diklik
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtId.setText(tableModel.getValueAt(row, 0).toString());
                txtName.setText(tableModel.getValueAt(row, 1).toString());
                txtAge.setText(tableModel.getValueAt(row, 2).toString());
                txtDiagnosis.setText(tableModel.getValueAt(row, 3).toString());
            }
        });
    }

    private void loadTable() {
        try {
            tableModel.setRowCount(0);
            dao.reload();
            while (dao.next()) {
                Patient p = dao.getCurrentPatient();
                Vector<Object> row = new Vector<>();
                row.add(p.getId());
                row.add(p.getName());
                row.add(p.getAge());
                row.add(p.getDiagnosis());
                tableModel.addRow(row);
            }
        } catch (SQLException ex) {
            showError(ex);
        }
    }

    private void clearForm() {
        txtId.setText("");
        txtName.setText("");
        txtAge.setText("");
        txtDiagnosis.setText("");
        table.clearSelection();
    }

    private void tambahPasien() {
        try {
            int id = Integer.parseInt(txtId.getText());
            String name = txtName.getText();
            int age = Integer.parseInt(txtAge.getText());
            String diagnosis = txtDiagnosis.getText();

            tableModel.addRow(new Object[]{id, name, age, diagnosis});
            showMessage("Data berhasil ditambahkan ke tabel.");
            clearForm();
        } catch (Exception ex) {
            showError("Input tidak valid: " + ex.getMessage());
        }
    }

    private void saveNew() {
        try {
            int id = Integer.parseInt(txtId.getText());
            int age = Integer.parseInt(txtAge.getText());
            Patient p = new Patient(id, txtName.getText(), age, txtDiagnosis.getText());
            dao.insert(p);
            loadTable();
            clearForm();
            JOptionPane.showMessageDialog(this, "Data disimpan ke database.");
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void deleteSelected() {
        try {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Pilih baris terlebih dahulu.");
                return;
            }
            int id = Integer.parseInt(tableModel.getValueAt(row, 0).toString());
            dao.deleteById(id);
            loadTable();
            clearForm();
            JOptionPane.showMessageDialog(this, "Data dihapus dari database.");
        } catch (Exception ex) {
            showError(ex);
        }
    }

    private void showMessage(String msg) {
        JOptionPane.showMessageDialog(this, msg);
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void showError(Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PatientForm().setVisible(true));
    }
}
