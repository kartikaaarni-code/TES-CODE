package hospital;

import java.sql.*;

public class PatientDAO {
    private Connection con;
    private Statement stmt;
    private ResultSet rs;

    public PatientDAO() throws SQLException {
        con = DBConnection.getConnection();
        stmt = con.createStatement(
            ResultSet.TYPE_SCROLL_INSENSITIVE,
            ResultSet.CONCUR_READ_ONLY
        );
        reload();
    }

    public void reload() throws SQLException {
        String sql = "SELECT * FROM PATIENTS ORDER BY ID";
        rs = stmt.executeQuery(sql);
        if (rs.next()) {
            rs.beforeFirst();
        }
    }

    public boolean next() throws SQLException {
        return rs.next();
    }

    public boolean previous() throws SQLException {
        return rs.previous();
    }

    public Patient getCurrentPatient() throws SQLException {
        return new Patient(
            rs.getInt("ID"),
            rs.getString("NAME"),
            rs.getInt("AGE"),
            rs.getString("DIAGNOSIS")
        );
    }

    public void insert(Patient p) throws SQLException {
        String check = "SELECT COUNT(*) FROM PATIENTS WHERE ID = ?";
        PreparedStatement chk = con.prepareStatement(check);
        chk.setInt(1, p.getId());
        ResultSet rsChk = chk.executeQuery();
        rsChk.next();
        if (rsChk.getInt(1) > 0) {
            throw new SQLException("ID " + p.getId() + " sudah ada.");
        }

        String sql = "INSERT INTO PATIENTS (ID, NAME, AGE, DIAGNOSIS) VALUES (?, ?, ?, ?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, p.getId());
        ps.setString(2, p.getName());
        ps.setInt(3, p.getAge());
        ps.setString(4, p.getDiagnosis());
        ps.executeUpdate();
        reload();
    }

    public void deleteById(int id) throws SQLException {
        String sql = "DELETE FROM PATIENTS WHERE ID = ?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, id);
        ps.executeUpdate();
        reload();
    }
}
