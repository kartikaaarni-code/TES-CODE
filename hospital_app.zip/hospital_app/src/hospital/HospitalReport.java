package hospital;

import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;

import javax.swing.*;
import java.io.InputStream;
import java.sql.Connection;

public class HospitalReport {
    public static void showReport(JFrame parent) {
        try {
            InputStream reportStream = HospitalReport.class.getResourceAsStream("/report/report_pasien.jrxml");
            if (reportStream == null) {
                throw new RuntimeException("File report_pasien.jrxml tidak ditemukan!");
            }

            JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);

            // Gunakan DBConnection, bukan DB
            Connection conn = DBConnection.getConnection();

            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, conn);

            JasperViewer viewer = new JasperViewer(jasperPrint, false);
            viewer.setTitle("Laporan Data Pasien");
            viewer.setVisible(true);
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(parent, "Gagal menampilkan laporan: " + ex.getMessage());
        }
    }
}
